package minapc.java.advanceapp.test;

public class OracleHAndler implements DatabaseFace {
    @Override
    public void connect(String ip, String username, String pass, String dbName) {

    }

    @Override
    public void insert(String query) {

    }

    @Override
    public void update(String query) {

    }

    @Override
    public void delete(String query) {

    }

    @Override
    public String select(String query) {
        return null;
    }
}
