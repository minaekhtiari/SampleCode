package minapc.java.advanceapp.MVP_Weather;

import minapc.java.advanceapp.weather.pojo.Forecast;
import minapc.java.advanceapp.weather.pojo.YahooWeather;

public class Presenter implements Contract.Presenter {
    private Contract.View view;
    Model model = new Model() ;
    @Override
    public void attachView(Contract.View view) {
        this.view = view;
        model.attachPresenter(this);
    }

    @Override
    public void searchByWord(String word) {
        model.search(word);
        view.onDataLoading();
    }

    @Override
    public void receivedDataSuccess(YahooWeather yahoo) {
       view.showSuccessData(yahoo);
        view.onDataLoadingFinished();
    }

    @Override
    public void onFailure(String msg) {
        view.onFailure(msg);
        view.onDataLoadingFinished();
    }

    @Override
    public void onSelectForecast(Forecast forecast) {
        view.showForecastData(forecast);
    }
}
