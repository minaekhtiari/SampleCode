package minapc.java.advanceapp.recycler;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;

public class MyRecyclerActivity extends BaseActivity {
    RecyclerView myRecycler;
    String img = "http://media.irib.ir/assets//radio_slider/20180122150158_2203.png";
    EditText word;
    private FoodsAdapter adapter;
    List<FoodModel> foods;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_recycler);
        bind();

//        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.hideSoftInputFromWindow(findViewById(R.id.word).getWindowToken(), 0);

        FoodModel f1 = FoodModel.newBuilder().foodName("ghormesabzi")
                .price(12000).restaurant("Orkide").type("Sonnati")
                .imageURL(img).build();


        FoodModel f2 = FoodModel.newBuilder().foodName("fesenjoon")
                .price(12000).restaurant("Orkide").type("Sonnati")
                .imageURL(img).build();


        FoodModel f3 = FoodModel.newBuilder().foodName("gheyme")
                .price(12000).restaurant("Orkide").type("Sonnati")
                .imageURL(img).build();


        FoodModel f4 = FoodModel.newBuilder().foodName("burger")
                .price(12000).restaurant("Orkide").type("Sonnati")
                .imageURL(img).build();


        FoodModel f5 = FoodModel.newBuilder().foodName("pitza")
                .price(12000).restaurant("Orkide").type("Sonnati")
                .imageURL(img).build();

        foods = new ArrayList<>();
        foods.add(f1);
        foods.add(f2);
        foods.add(f3);
        foods.add(f4);
        foods.add(f5);

        adapter = new FoodsAdapter(mContext, foods);

        LinearLayoutManager lm = new LinearLayoutManager(mContext, LinearLayoutManager.VERTICAL, false);

        myRecycler.setLayoutManager(lm);
        myRecycler.setAdapter(adapter);

    }

    void bind() {
        myRecycler = findViewById(R.id.myRecycler);
        word = findViewById(R.id.word);

        word.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filterList(charSequence.toString()) ;
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }


    void filterList(String word) {
        List<FoodModel> filteredFoods = new ArrayList<>();

        for (FoodModel food : foods) {
            if (food.getFoodName().toLowerCase().contains(word)) {
                food.setHtChars(word);
                filteredFoods.add(food);
            }
        }
        if (filteredFoods.size() > 0)
            adapter.setItems(filteredFoods);
        else
            adapter.setItems(foods);

    }
}
