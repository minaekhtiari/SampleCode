package minapc.java.advanceapp.SampleMVP;

public interface SampleContract {
    interface View{
        void onAgeReceived(int age) ;
    }
    interface Presenter{
        void attachView(View view) ;
        void receivedNameFamily(String name , String family) ;
        void onAgeReceived(int age) ;
    }

    interface Model{
        void attachPresenter(Presenter presenter) ;
        void getAgeByNameFamily(String name , String family) ;
    }

}
