package minapc.java.advanceapp.Music.ListMusics;

import android.view.Display;

import minapc.java.advanceapp.utils.PublicMethods;

public class ListModel implements ListContract.Model {
    private ListContract.Presenter presenter;

    @Override
    public void attachPresenter(ListContract.Presenter presenter) {

        this.presenter = presenter;
    }

    @Override
    public void loadMusics() {
        presenter.onLoadedMusics(PublicMethods.getMusics());
    }
}
