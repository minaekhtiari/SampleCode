package minapc.java.advanceapp.IMDB;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public interface IMDBWebInterFace {

    @GET("/")
    Call<IMDBPoJo> searchInIMDB(@Query("t") String word ,
                                @Query("apikey") String apikey  ) ;


}
