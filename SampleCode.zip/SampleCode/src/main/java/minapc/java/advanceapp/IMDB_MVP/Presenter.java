package minapc.java.advanceapp.IMDB_MVP;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public class Presenter implements IMDBMCPContract.Presenter {


    private IMDBMCPContract.View view;
    Model model = new Model();

    @Override
    public void attachView(IMDBMCPContract.View view) {
        this.view = view;
        model.attachPresenter(this);
    }

    @Override
    public void search(String word) {
        view.showLoading(true);
        model.search(word);
    }

    @Override
    public void onSuccessSearch(IMDBPoJo imdb) {
        view.showLoading(false);
        view.onSuccessSearch(imdb);
    }

    @Override
    public void onFail(String msg) {
        view.showLoading(false);
        view.onFail(msg);
    }

    @Override
    public void validateWord(String word) {
        if (word != null)
            search(word);
        else
            view.onWordNull();
    }
}
