package minapc.java.advanceapp.FCM;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class FCMGetMessage extends FirebaseMessagingService {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);


        Log.d("fcm_", "From: " + remoteMessage.getFrom());
        Log.d("fcm_", "body: " +  remoteMessage.getNotification().getBody());
        Log.d("fcm_", "title: " +  remoteMessage.getNotification().getTitle());


        if (remoteMessage.getData().size() > 0) {

            Log.d("fcm_", "Message data payload: " + remoteMessage.getData());



        }

    }
}
