package minapc.java.advanceapp;

public interface TestInterface {

    void setName();
    String getName();

}
