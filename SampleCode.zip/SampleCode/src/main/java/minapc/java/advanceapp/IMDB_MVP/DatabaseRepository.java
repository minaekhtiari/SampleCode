package minapc.java.advanceapp.IMDB_MVP;

import java.util.List;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public class DatabaseRepository implements modelRepository.Database {


    private Model model;

    @Override
    public void attachModel(Model model) {
        this.model = model;
    }

    @Override
    public void saveDataToDB(IMDBPoJo pojo) {
        IMDBPojoDatabase db = new IMDBPojoDatabase();
        db.setDirector(pojo.getDirector());
        db.setTitle(pojo.getTitle());
        db.setPoster(pojo.getPoster());
        db.setYear(pojo.getYear());
        db.save();
    }

    @Override
    public void getData(String word) {
        List<IMDBPojoDatabase> movies = IMDBPojoDatabase.find(IMDBPojoDatabase.class, "title like ?  ", word);

        IMDBPoJo pojo = new IMDBPoJo();
        pojo.setTitle(movies.get(0).getTitle());
        pojo.setDirector(movies.get(0).getDirector());
        pojo.setPoster(movies.get(0).getPoster());

        if (movies != null)
            model.onReceivedData(pojo, RepoType.Database);
        else
            model.onFailed(word , RepoType.Database);

    }
}
