package minapc.java.advanceapp.IMDB;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public class IMDBModel implements IMDBContract.Model {
    private IMDBContract.Presenter presenter;

    @Override
    public void attachPresenter(IMDBContract.Presenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public void search(String word) {

        API.getClient().create(IMDBWebInterFace.class).
                searchInIMDB(word , "70ad462a").enqueue(new Callback<IMDBPoJo>() {
            @Override
            public void onResponse(Call<IMDBPoJo> call, Response<IMDBPoJo> response) {
                presenter.receivedDataSuccess(response.body());
            }

            @Override
            public void onFailure(Call<IMDBPoJo> call, Throwable t) {
                presenter.onFailure(t.toString());
            }
        });
    }


}
