package minapc.java.advanceapp.IMDB_MVP;

public enum RepoType {
    Rest, Database ;
}
