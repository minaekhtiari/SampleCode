package minapc.java.advanceapp.IMDB_MVP;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import minapc.java.advanceapp.IMDB.IMDBWebInterFace;
import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public class RestRepository implements modelRepository.Rest{


    private Model model;

    @Override
    public void attachModel(Model model) {
        this.model = model;
    }

    @Override
    public void getData(final String word) {
        API.getClient().create(IMDBWebInterFace.class)
                .searchInIMDB(word,"70ad462a").enqueue(new Callback<IMDBPoJo>() {
            @Override
            public void onResponse(Call<IMDBPoJo> call, Response<IMDBPoJo> response) {
                model.onReceivedData(response.body() , RepoType.Rest);
            }

            @Override
            public void onFailure(Call<IMDBPoJo> call, Throwable t) {
                model.onFailed(word , RepoType.Rest);
            }
        });
    }
}
