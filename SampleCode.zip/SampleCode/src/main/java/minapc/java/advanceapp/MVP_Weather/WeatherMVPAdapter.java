package minapc.java.advanceapp.MVP_Weather;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.weather.pojo.Forecast;

public class WeatherMVPAdapter extends RecyclerView.Adapter<WeatherMVPAdapter.Holder> {


    Context mContext;
    List<Forecast> forecasts;

    public WeatherMVPAdapter(Context mContext, List<Forecast> forecasts) {
        this.mContext = mContext;
        this.forecasts = forecasts;
    }

    @Override
    public WeatherMVPAdapter.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.forecast_item, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull WeatherMVPAdapter.Holder holder, int position) {
        holder.day.setText(forecasts.get(position).getDay());
        holder.high.setText(forecasts.get(position).getHigh());
        holder.low.setText(forecasts.get(position).getLow());
        holder.text.setText(forecasts.get(position).getText());
    }

    @Override
    public int getItemCount() {
        return forecasts.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView high, low, day, text;

        public Holder(View itemView) {
            super(itemView);
            day = itemView.findViewById(R.id.day);
            low = itemView.findViewById(R.id.low);
            high = itemView.findViewById(R.id.high);
            text = itemView.findViewById(R.id.text);
            text.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onItemClick.onItemClick(forecasts.get(getAdapterPosition()  ));
                }
            });
        }
    }

    public void setOnItemClick(WeatherMVPAdapter.onItemClick onItemClick) {
        this.onItemClick = onItemClick;
    }

    onItemClick onItemClick ;
    public interface onItemClick{
        void onItemClick(Forecast forecast) ;
    }
}
