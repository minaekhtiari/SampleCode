package minapc.java.advanceapp.ServiceSample;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.BaseActivity;

public class ServiceActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service);

        findViewById(R.id.start).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sampleService = new Intent(mContext, SampleService.class);
//                Bundle b = new Bundle() ;
//                b.putString("name" , "Mina");
//                sampleService.putExtra("data" , b) ;
                sampleService.putExtra("url" , "urllll") ;
                startService(sampleService);


            }
        });
    }
}
