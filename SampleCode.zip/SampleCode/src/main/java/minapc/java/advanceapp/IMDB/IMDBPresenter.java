package minapc.java.advanceapp.IMDB;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public class IMDBPresenter implements IMDBContract.Presenter {
    private IMDBContract.View view;
    IMDBContract.Model model = new IMDBModel() ;

    @Override
    public void attachView(IMDBContract.View view) {
        this.view = view;
        model.attachPresenter(this);
    }

    @Override
    public void searchByWord(String word) {
        model.search(word);
        view.onDataLoading();
    }

    @Override
    public void receivedDataSuccess(IMDBPoJo result) {
        view.showSuccesData(result);
        view.onDataLoadingFinished();
    }

    @Override
    public void onFailure(String msg) {
        view.onFailure(msg);
        view.onDataLoadingFinished();
    }
}
