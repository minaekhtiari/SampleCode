package minapc.java.advanceapp.Music.ListMusics;


import java.util.List;

import minapc.java.advanceapp.Music.MusicPOJO;

public interface ListContract {

    interface View {
        void onLoadedMusics(List<MusicPOJO>musics) ;
        void playMusic(MusicPOJO music) ;
    }

    interface Presenter {
        void attachView( View view) ;
        void onLoadedMusics(List<MusicPOJO>musics) ;
        void musicSelected(MusicPOJO music) ;

    }

    interface Model {
        void attachPresenter( Presenter presenter) ;
        void loadMusics() ;
    }

}
