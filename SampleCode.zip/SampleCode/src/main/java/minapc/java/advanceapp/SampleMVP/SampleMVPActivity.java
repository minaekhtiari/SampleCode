package minapc.java.advanceapp.SampleMVP;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.PublicMethods;

public class SampleMVPActivity extends AppCompatActivity implements SampleContract.View {
    EditText name, family;
    Button getData;

    SamplePresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sample_mvp);
        bindViews();
        presenter = new SamplePresenter();
        presenter.attachView(this);

    }

    private void bindViews() {
        name = findViewById(R.id.name);
        family = findViewById(R.id.family);
        getData = findViewById(R.id.getData);
        getData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                presenter.receivedNameFamily(name.getText().toString() , family.getText().toString());
            }
        });
    }

    @Override
    public void onAgeReceived(int age) {
        PublicMethods.showToast(this, "my age is " + age);
    }
}
