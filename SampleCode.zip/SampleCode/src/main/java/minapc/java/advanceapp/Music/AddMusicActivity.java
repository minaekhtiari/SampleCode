package minapc.java.advanceapp.Music;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import minapc.java.advanceapp.Music.ListMusics.MusicsListActivity_;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.customViews.MyEditText;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;

@EActivity(R.layout.activity_add_music)
public class AddMusicActivity extends BaseActivity implements AddMusicContract.View{

    AddMusicContract.Presenter presenter = new AddMusicPresenter() ;
    @ViewById
    MyEditText  title ;
    @ViewById
    MyEditText  url ;
    @ViewById
    MyEditText  singer ;
    @ViewById
    MyEditText  album ;
    @ViewById
    MyEditText  cover ;

    @AfterViews
    void init(){
        presenter.attachView(this);
    }
    @Click
    void save(){
        MusicPOJO musicPOJO = MusicPOJO.newBuilder()
                .album(album.text())
                .cover(cover.text())
                .singer(singer.text())
                .url(url.text())
                .title(title.text())
                .build() ;
        presenter.addMusic(musicPOJO);
    }


    @Override
    public void afterSave() {
      //  clean() ;
        PublicMethods.showToast(mContext , "new music has been added");
        PublicMethods.showToast(mContext , PublicMethods.getMusics().size()+"");
    }

    @Override
    public void showListPage() {
        MusicsListActivity_.intent(mContext).start() ;
    }


    @Click
    void list(){
            presenter.list();
    }

    void clean(){
        title.setText("");
        album.setText("");
        cover.setText("");
        singer.setText("");
        url.setText("");
    }
}
