package minapc.java.advanceapp.Music;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;
import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import minapc.java.advanceapp.MainActivity;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.customViews.MyImageView;

@EActivity(R.layout.activity_detail_music)
public class DetailMusicActivity extends AppCompatActivity {

    @ViewById
    MyImageView cover;

    @ViewById
    TextView title;
    @ViewById
    TextView album;

    @ViewById
    ProgressBar progress;

    @AfterViews
    void init() {
        if (getIntent().hasExtra("cover"))
            cover.load(getIntent().getStringExtra("cover"));
    }

    @Subscribe
    public void onMusicPlaying(MusicPOJO musicPOJO) {
        album.setText(musicPOJO.getAlbum());
        progress.setProgress(musicPOJO.getPercent());
        title.setText(musicPOJO.getTitle());
        cover.load(musicPOJO.getCover());
    }


    @Override
    protected void onResume() {
        super.onResume();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }
}
