package minapc.java.advanceapp.Music.ListMusics;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import java.util.List;

import minapc.java.advanceapp.Music.DetailMusicActivity;
import minapc.java.advanceapp.Music.DetailMusicActivity_;
import minapc.java.advanceapp.Music.MusicPOJO;
import minapc.java.advanceapp.Music.MusicPlayerService;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.BaseActivity;

@EActivity(R.layout.activity_musics_list)
public class MusicsListActivity extends BaseActivity implements ListContract.View {
    ListContract.Presenter presenter = new ListPresenter();

    @ViewById
    ListView list;

    MusicsListAdapter adapter;

    @AfterViews
    void init() {
        presenter.attachView(this);
    }

    @Override
    public void onLoadedMusics(List<MusicPOJO> musics) {
        adapter = new MusicsListAdapter(mContext, musics);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                MusicPOJO musicPOJO = (MusicPOJO) adapterView.getItemAtPosition(position);
                presenter.musicSelected(musicPOJO);
            }
        });
    }

    @Override
    public void playMusic(MusicPOJO music) {
        Intent playService = new Intent(mContext, MusicPlayerService.class);
        playService.putExtra("music_id", music.getId() + "");
        startService(playService);


        adapter.handleClick( music);

    }
}
