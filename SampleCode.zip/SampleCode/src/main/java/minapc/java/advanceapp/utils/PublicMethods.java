package minapc.java.advanceapp.utils;

import android.content.Context;
import android.widget.Toast;

import java.util.List;

import minapc.java.advanceapp.Music.MusicPOJO;

public class PublicMethods {


    public static void showToast(Context mContext , String msg){
        Toast.makeText(mContext, msg, Toast.LENGTH_SHORT).show();
    }

    public static List<MusicPOJO> getMusics(){
        return  MusicPOJO.listAll(MusicPOJO.class) ;
    }

    public static MusicPOJO getMusicByID(String id){
        return MusicPOJO.findById(MusicPOJO.class ,
                Long.parseLong(id)) ;
    }

}
