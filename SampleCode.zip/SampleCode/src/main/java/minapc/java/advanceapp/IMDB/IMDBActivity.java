package minapc.java.advanceapp.IMDB;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.UiThread;
import org.androidannotations.annotations.ViewById;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.customViews.MyEditText;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;

@EActivity(R.layout.activity_imdb)
public class IMDBActivity extends BaseActivity implements IMDBContract.View {

    IMDBContract.Presenter presenter = new IMDBPresenter();

    @ViewById
    MyEditText word;

    @ViewById
    ImageView cover;

    @ViewById
    TextView result;

    ProgressDialog dialog;

    @AfterViews
    void initView() {
        presenter.attachView(this);
        dialog = new ProgressDialog(mContext);
        dialog.setTitle("Loading");
        dialog.setMessage("Please wait");
    }

    @Click
    void search() {
        presenter.searchByWord(word.text());
    }

    @Override
    public void showSuccesData(IMDBPoJo serverResponse) {
        result.setText(serverResponse.getTitle() + " " +
                serverResponse.getDirector());
        Picasso.get().load(serverResponse.getPoster()).into(cover);
    }

    @Override
    public void onFailure(String msg) {
        PublicMethods.showToast(mContext , msg);
    }

    @Override
    public void onDataLoading() {
        dialog.show();
    }

    @Override
    public void onDataLoadingFinished() {
        dialog.dismiss();
    }
}
