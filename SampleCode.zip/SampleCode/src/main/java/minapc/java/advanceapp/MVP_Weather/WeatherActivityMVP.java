package minapc.java.advanceapp.MVP_Weather;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;
import minapc.java.advanceapp.weather.pojo.Forecast;
import minapc.java.advanceapp.weather.pojo.YahooWeather;

public class WeatherActivityMVP extends BaseActivity implements Contract.View ,WeatherMVPAdapter.onItemClick{
    Contract.Presenter presenter = new Presenter();
    TextView result;
    Button search;
    EditText city;
    RecyclerView forecasts;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_mvp);
        bind();
        presenter.attachView(this);
        dialog = new ProgressDialog(mContext);
        dialog.setTitle("Loading");
        dialog.setMessage("Please wait");
    }

    private void bind() {
        result = findViewById(R.id.result);
        search = findViewById(R.id.search);
        forecasts = findViewById(R.id.forecasts);
        city = findViewById(R.id.city);
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                presenter.searchByWord(city.getText().toString());
            }
        });
    }

    @Override
    public void showSuccessData(YahooWeather yahoo) {
        WeatherMVPAdapter adapter = new WeatherMVPAdapter(mContext, yahoo.getQuery().getResults().getChannel().getItem().getForecast());
        forecasts.setAdapter(adapter);
        adapter.setOnItemClick(this);
    }

    @Override
    public void onFailure(String msg) {
        PublicMethods.showToast(mContext, msg);
    }

    @Override
    public void onDataLoading() {
        dialog.show();
    }

    @Override
    public void onDataLoadingFinished() {
        dialog.dismiss();
    }

    @Override
    public void showForecastData(Forecast forecast) {
        PublicMethods.showToast(mContext , forecast.getDay() + " " + forecast.getText());
    }

    @Override
    public void onItemClick(Forecast forecast) {
        presenter.onSelectForecast(forecast);
    }
}
