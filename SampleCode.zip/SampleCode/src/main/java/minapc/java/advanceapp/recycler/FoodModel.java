package minapc.java.advanceapp.recycler;

import com.squareup.picasso.Picasso;

public class FoodModel {
    private String foodName;
    private int price;
    private String restaurant;
    private String type;
    private String imageURL ;
    String htChars ="";

    public String getFoodName() {
        return foodName;
    }

    public String getHtChars() {
        return htChars;
    }

    public void setHtChars(String htChars) {
        this.htChars = htChars;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(String restaurant) {
        this.restaurant = restaurant;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    private FoodModel(Builder builder) {
        foodName = builder.foodName;
        price = builder.price;
        restaurant = builder.restaurant;
        type = builder.type;
        imageURL = builder.imageURL;
    }

    public static Builder newBuilder() {
        return new Builder();
    }


    public static final class Builder {
        private String foodName;
        private int price;
        private String restaurant;
        private String type;
        private String imageURL;

        private Builder() {
        }

        public Builder foodName(String val) {
            foodName = val;
            return this;
        }

        public Builder price(int val) {
            price = val;
            return this;
        }

        public Builder restaurant(String val) {
            restaurant = val;
            return this;
        }

        public Builder type(String val) {
            type = val;
            return this;
        }

        public Builder imageURL(String val) {
            imageURL = val;
            return this;
        }

        public FoodModel build() {
            return new FoodModel(this);
        }
    }
}
