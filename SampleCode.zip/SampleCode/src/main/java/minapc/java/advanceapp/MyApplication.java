package minapc.java.advanceapp;

import android.app.Application;

import com.google.firebase.messaging.FirebaseMessaging;
import com.orhanobut.hawk.Hawk;
import com.orm.SugarApp;

import minapc.java.advanceapp.FCM.FCMGetToken;

public class MyApplication extends SugarApp {

    @Override
    public void onCreate() {
        super.onCreate();
        Hawk.init(this).build();
        FCMGetToken fcm = new FCMGetToken() ;

        FirebaseMessaging.getInstance().subscribeToTopic("offers");
        FirebaseMessaging.getInstance().subscribeToTopic("sport");
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
