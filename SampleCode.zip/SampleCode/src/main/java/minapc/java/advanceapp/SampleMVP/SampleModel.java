package minapc.java.advanceapp.SampleMVP;

public class SampleModel implements SampleContract.Model {

    SampleContract.Presenter presenter ;

    @Override
    public void attachPresenter(SampleContract.Presenter presenter) {
        this.presenter = presenter ;
    }

    @Override
    public void getAgeByNameFamily(String name, String family) {
        if( name.equalsIgnoreCase("ali") && family.equalsIgnoreCase("hasani"))
            presenter.onAgeReceived(10);
        else
            presenter.onAgeReceived(30);
    }
}
