package minapc.java.advanceapp.MVP_Weather;

import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import minapc.java.advanceapp.weather.pojo.YahooWeather;

public interface YahooWInterface {

    @GET("yql/")
    Observable<YahooWeather> getWeather(@Query("q") String query , @Query("format") String format ) ;

}
