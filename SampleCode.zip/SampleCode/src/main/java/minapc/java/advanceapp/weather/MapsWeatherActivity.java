package minapc.java.advanceapp.weather;

import android.app.ProgressDialog;
import android.content.Context;
import android.location.Location;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;

import cz.msebera.android.httpclient.Header;
import io.nlopez.smartlocation.OnLocationUpdatedListener;
import io.nlopez.smartlocation.SmartLocation;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.PublicMethods;
import minapc.java.advanceapp.weather.pojo.YahooWeather;

public class MapsWeatherActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    Context mContext = this;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_weather);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        dialog = new ProgressDialog(mContext);
        dialog.setTitle("Waiting");
        dialog.setMessage("Please wait to load response");
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        SmartLocation.with(mContext).location()
                .start(new OnLocationUpdatedListener() {


                    @Override
                    public void onLocationUpdated(Location location) {
                        location.getLatitude();
                        location.getLongitude();
                    }
                });


        mMap.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(mContext,
                        R.raw.mapstyle));


        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setCompassEnabled(true);

        mMap.setOnCameraIdleListener(new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {
                double lat = mMap.getCameraPosition().target.latitude;
                double lng = mMap.getCameraPosition().target.longitude;
                getWeather(lat, lng);
                //PublicMethods.showToast(mContext, lat + " " + lng);
            }
        });
//
//        LatLng home = new LatLng(35.730554, 51.437900);
//        mMap.addMarker(new MarkerOptions().position(home).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(home));
    }


    void getWeather(double lat, double lng) {
        String url = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(SELECT%20woeid%20FROM%20geo.places%20WHERE%20text%3D%22(" + lat + "," + lng + ")%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";

        AsyncHttpClient client = new AsyncHttpClient();

        client.get(url, new TextHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                dialog.show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                PublicMethods.showToast(mContext, throwable.toString());
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                parseResponse(responseString);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                dialog.dismiss();
            }
        });

    }

    void parseResponse(String response) {
        Gson gson = new Gson();
        YahooWeather yWeather = gson.fromJson(response, YahooWeather.class);

        if (yWeather.getQuery().getCount() == 1) {

            String location = yWeather.getQuery().getResults().getChannel().getLocation().getCountry()
                    + ", " + yWeather.getQuery().getResults().getChannel().getLocation().getCity();
            PublicMethods.showToast(mContext,
                    location + " " + yWeather.getQuery().getResults().getChannel().getItem().getCondition().getTemp()
                            + " F"
            );
        } else {
            PublicMethods.showToast(mContext, "data not found");
        }


    }


}
