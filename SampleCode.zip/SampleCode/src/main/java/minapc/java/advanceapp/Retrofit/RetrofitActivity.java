package minapc.java.advanceapp.Retrofit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.TestInterface;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;

public class RetrofitActivity extends BaseActivity {
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrofit);
        result = findViewById(R.id.result);

       // API.getClient().create(WebServices.class).getPRofile("erferfere")


        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    //call inside background thread
                    IPPoJOModel model =  API.getClient().create(WebServices.class).getIP().execute().body() ;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //call inside ui thread
                        }
                    });
                }catch (Exception e){

                }
            }
        }).start();


        WebServices aa = API.getClient().create(WebServices.class);


        aa.getIP( ).enqueue(new Callback<IPPoJOModel>() {
            @Override
            public void onResponse(Call<IPPoJOModel> call, Response<IPPoJOModel> response) {

                int responseCode = response.code() ;

                IPPoJOModel model = response.body();
                result.setText(model.getCountry() + " " + model.getCity() + " "
                        + model.getIsp());
            }

            @Override
            public void onFailure(Call<IPPoJOModel> call, Throwable t) {
                PublicMethods.showToast(mContext, t.toString());
            }
        });



    }


}
