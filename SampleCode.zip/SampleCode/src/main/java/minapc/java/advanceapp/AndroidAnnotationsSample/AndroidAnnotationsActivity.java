package minapc.java.advanceapp.AndroidAnnotationsSample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.widget.EditText;

import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;

@EActivity(R.layout.activity_android_annotations)
public class AndroidAnnotationsActivity extends BaseActivity {

    @ViewById
    EditText username ;

    @Click
    void showToast(){
        PublicMethods.showToast(mContext , username.getText().toString());
    }




}
