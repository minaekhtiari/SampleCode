package minapc.java.advanceapp.Retrofit;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface WebServices {

    //https://futurestud.io

    @Headers("content type : json")
    @GET("json")
    Call<IPPoJOModel> getIP();


    @GET("json")
    Call<IPPoJOModel> getPRofile( @Header("token") String token);

//    http://google.com/user/1
//
//    @GET("json")
//    Call<IPPoJOModel> getIP(@Path("id") String id) ;
//
//
//    http://google.com/?username=ali&family=231
//
//    @GET("")
//    Call<IPPoJOModel> get(@Query("username") String username
//    , @Query("family") String family) ;
//

}
