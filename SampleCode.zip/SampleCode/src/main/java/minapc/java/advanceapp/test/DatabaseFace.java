package minapc.java.advanceapp.test;

public interface DatabaseFace {

    void connect(String ip, String username, String pass, String dbName);

    void insert(String query);

    void update(String query);

    void delete(String query);

    String select(String query);

}
