package minapc.java.advanceapp.Music.ListMusics;

import java.util.List;

import minapc.java.advanceapp.Music.MusicPOJO;

public class ListPresenter implements ListContract.Presenter {
    private ListContract.View view;
    ListContract.Model model = new ListModel();

    @Override
    public void attachView(ListContract.View view) {

        this.view = view;
        model.attachPresenter(this);
        model.loadMusics();
    }

    @Override
    public void onLoadedMusics(List<MusicPOJO> musics) {
        view.onLoadedMusics(musics);
    }

    @Override
    public void musicSelected(MusicPOJO music) {
        view.playMusic(music);
    }
}
