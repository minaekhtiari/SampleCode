package minapc.java.advanceapp.IMDB_MVP;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public class Model implements IMDBMCPContract.Model {
    private IMDBMCPContract.Presenter presenter;
    RestRepository restRepository = new RestRepository();
    DatabaseRepository databaseRepository = new DatabaseRepository();
    @Override
    public void attachPresenter(IMDBMCPContract.Presenter presenter) {
        this.presenter = presenter;
        restRepository.attachModel(this);
        databaseRepository.attachModel(this);
    }

    @Override
    public void search(String word) {
        databaseRepository.getData(word);
    }

    @Override
    public void onReceivedData(IMDBPoJo imdb, RepoType type) {
        if (type == RepoType.Rest) {
            databaseRepository.saveDataToDB(imdb);
            presenter.onSuccessSearch(imdb);
        } else if(type == RepoType.Database){
            presenter.onSuccessSearch(imdb);
        }

    }

    @Override
    public void onFailed(String word , RepoType type) {
        if (type == RepoType.Rest) {
            presenter.onFail("error in webservice call");
        } else if(type == RepoType.Database){
            restRepository.getData(word);
        }
    }


}
