package minapc.java.advanceapp.SampleMVP;

public class SamplePresenter implements SampleContract.Presenter {

    SampleModel model ;
    private  SampleContract.View  view ;


    public SamplePresenter( ) {
        model = new SampleModel() ;
        model.attachPresenter(this);
    }


    @Override
    public void attachView(SampleContract.View view) {
        this.view = view ;
    }

    @Override
    public void receivedNameFamily(String name, String family) {
        model.getAgeByNameFamily(name , family);
    }

    @Override
    public void onAgeReceived(int age) {
        view.onAgeReceived(age);
    }


}
