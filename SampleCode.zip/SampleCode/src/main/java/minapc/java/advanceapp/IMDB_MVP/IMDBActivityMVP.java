package minapc.java.advanceapp.IMDB_MVP;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ViewById;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.customViews.MyEditText;
import minapc.java.advanceapp.utils.BaseActivity;

@EActivity(R.layout.activity_imdbmvp)
public class IMDBActivityMVP extends BaseActivity implements IMDBMCPContract.View {

    Presenter presenter = new Presenter();
    ProgressDialog dialog;

    @ViewById
    MyEditText word;

    @ViewById
    ImageView cover ;

    @ViewById
    TextView result ;

    @Click
    void search() {
        presenter.validateWord(word.text());
    }


    @AfterViews
    void init() {
        presenter.attachView(this);
        dialog = new ProgressDialog(mContext);
        dialog.setTitle("loading");
        dialog.setMessage("please wait");
    }

    @Override
    public void onWordNull() {
        word.setError("field is empty");
    }

    @Override
    public void onSuccessSearch(IMDBPoJo imdb) {
        showLoading(false);
    }

    @Override
    public void onFail(String msg) {
        showLoading(false);
    }

    @Override
    public void showLoading(Boolean show) {
        if (show)
            dialog.show();
        else
            dialog.dismiss();
    }
}

