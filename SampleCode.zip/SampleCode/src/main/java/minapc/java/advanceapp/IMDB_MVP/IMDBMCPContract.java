package minapc.java.advanceapp.IMDB_MVP;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public interface IMDBMCPContract {

    interface View{
        void onWordNull() ;
        void onSuccessSearch(IMDBPoJo imdb) ;
        void onFail(String msg) ;
        void showLoading(Boolean show) ;
    }
    interface Presenter{
        void attachView(View view) ;
        void search(String word) ;
        void onSuccessSearch(IMDBPoJo imdb) ;
        void onFail(String msg) ;
        void validateWord(String word) ;

    }
    interface Model{
        void attachPresenter(Presenter presenter) ;
        void search(String word) ;
        void onReceivedData(IMDBPoJo imdb ,RepoType type) ;
        void onFailed(String word , RepoType type) ;
    }
}
