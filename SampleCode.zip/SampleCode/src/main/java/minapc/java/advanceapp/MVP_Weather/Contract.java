package minapc.java.advanceapp.MVP_Weather;

import minapc.java.advanceapp.IMDB.IMDBContract;
import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;
import minapc.java.advanceapp.weather.pojo.Forecast;
import minapc.java.advanceapp.weather.pojo.YahooWeather;

public interface Contract {

    interface View{
        void showSuccessData(YahooWeather yahoo) ;
        void onFailure(String msg);
        void onDataLoading() ;
        void onDataLoadingFinished() ;

        void showForecastData(Forecast forecast) ;
    }
    interface Presenter{
        void attachView( View v)  ;
        void searchByWord(String word) ;
        void receivedDataSuccess( YahooWeather yahoo) ;
        void onFailure(String msg);
        void onSelectForecast(Forecast forecast) ;
    }
    interface Model{
        void attachPresenter( Presenter presenter) ;
        void search(String word) ;
    }
}
