package minapc.java.advanceapp.IMDB;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public interface IMDBContract {

    interface View{
        void showSuccesData(IMDBPoJo result) ;
        void onFailure(String msg);
        void onDataLoading() ;
        void onDataLoadingFinished() ;
    }
    interface Presenter{
        void attachView(View v)  ;
        void searchByWord(String word) ;
        void receivedDataSuccess(IMDBPoJo result) ;
        void onFailure(String msg);
    }
    interface Model{
        void attachPresenter(Presenter presenter) ;
        void search(String word) ;
    }
}
