package minapc.java.advanceapp.weather;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;

import cz.msebera.android.httpclient.Header;
import minapc.java.advanceapp.R;
import minapc.java.advanceapp.customViews.MyEditText;
import minapc.java.advanceapp.utils.BaseActivity;
import minapc.java.advanceapp.utils.PublicMethods;
import minapc.java.advanceapp.weather.pojo.YahooWeather;

public class WeatherActivityForm extends BaseActivity implements View.OnClickListener {
    MyEditText cityName;
    TextView result;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_form);
        bind();

    }

    void bind() {
        cityName = findViewById(R.id.cityName);
        result = findViewById(R.id.result);
        dialog = new ProgressDialog(mContext);
        dialog.setTitle("Waiting");
        dialog.setMessage("Please wait to load response");
        findViewById(R.id.show).setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.show)
            getWeather(cityName.text());
    }

    void getWeather(String city) {
        AsyncHttpClient client = new AsyncHttpClient();
        String url = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22" +
                city + "%2C%20ir%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";

        client.get(url, new TextHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                dialog.show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                PublicMethods.showToast(mContext, throwable.toString());
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                parseResponse(responseString);
            }

            @Override
            public void onFinish() {
                super.onFinish();
                dialog.dismiss();
            }
        });
    }

    void parseResponse(String response) {
        Gson gson = new Gson();
        YahooWeather yWeather = gson.fromJson(response, YahooWeather.class);
        result.setText(

                cityName.text() + " : " +
                        yWeather.getQuery().getResults().getChannel().getItem().getCondition().getTemp()
                        + " F"
        );

    }
}
