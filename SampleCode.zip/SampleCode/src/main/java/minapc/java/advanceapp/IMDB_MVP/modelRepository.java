package minapc.java.advanceapp.IMDB_MVP;

import minapc.java.advanceapp.IMDB.pojo.IMDBPoJo;

public interface modelRepository {

    interface Rest{
        void attachModel(Model model) ;
        void getData(String word) ;
    }
    interface Database{
        void attachModel(Model model) ;
        void getData(String word) ;
        void saveDataToDB(IMDBPoJo pojo) ;
    }

}
