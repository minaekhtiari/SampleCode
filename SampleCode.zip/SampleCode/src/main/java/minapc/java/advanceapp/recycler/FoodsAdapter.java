package minapc.java.advanceapp.recycler;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import minapc.java.advanceapp.R;
import minapc.java.advanceapp.utils.PublicMethods;

public class FoodsAdapter
        extends RecyclerView.Adapter<FoodsAdapter.MyHolder> {

    Context mContext;
    List<FoodModel> foods;

    public FoodsAdapter(Context mContext, List<FoodModel> foods) {
        this.mContext = mContext;
        this.foods = foods;
    }

    public void setItems(List<FoodModel> newList) {
        foods = newList;
        notifyDataSetChanged();
    }

    @Override
    public FoodsAdapter.MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.foods_list_item, parent, false);
        return new MyHolder(v);
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @Override
    public void onBindViewHolder(@NonNull FoodsAdapter.MyHolder holder, int position) {
        if (foods.get(position).getHtChars().length() > 0) {

            String name = foods.get(position).getFoodName();


            name = name.replaceAll(foods.get(position).getHtChars().toLowerCase(), "<font color='red'>" + foods.get(position).getHtChars().toLowerCase() + "</font>");
            holder.name.setText(Html.fromHtml(name));

        } else {
            holder.name.setText(foods.get(position).getFoodName());
        }


        holder.type.setText(foods.get(position).getType());
        holder.price.setText(foods.get(position).getPrice() + "");
        Picasso.get().load(R.mipmap.ic_launcher).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return foods.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView name;
        TextView price;
        TextView type;

        public MyHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            price = itemView.findViewById(R.id.price);
            type = itemView.findViewById(R.id.type);
            img = itemView.findViewById(R.id.img);

            name.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    PublicMethods.showToast(mContext , foods.get(getAdapterPosition()).getFoodName());
                }
            });


        }
    }
}
